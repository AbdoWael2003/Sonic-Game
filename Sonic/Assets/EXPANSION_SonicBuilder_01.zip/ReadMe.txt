Preferably set up the scenario in meters cause the blocks measure 1 meter, 2 meters, 3 meters... This way you can move the elements 1 unit at a time and snap to the scene grid.
If the blocks are bigger or smaller than the grid units it will be more difficult to snap them together. You can always check the position and see if it is a round number
to make sure they are perfectly combined.

These files are an expansion from a bigger set:
https://www.turbosquid.com/es/FullPreview/1953802